# Pack Intent

## What this pack does
Provide local hello tools.

## Tools provided (English)
- "say hello"

## Inputs/outputs summary
Takes a name and returns a greeting.

## Capabilities & risk
Pure local tool; no external access.

## Failure modes
Missing name or invalid payload.

## Runner requirements
Runs with local runner.
